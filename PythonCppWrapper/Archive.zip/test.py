import myModule

def Main():
    print myModule.fib(3)
    print myModule.version()
    print myModule.mycard(50.1)

if __name__ == '__main__':
    Main()
