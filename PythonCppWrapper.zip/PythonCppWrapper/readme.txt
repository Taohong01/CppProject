This is about how to build c and c++ code and how to use python setup.py to install compile, 
build a module for python and then how to use python to call the functions declared and specified in c and c++.
